# Random Utilities Package
### Installation
```bash
pip install random_utilities
```

### Usage
```python
import random_utilities
random_utilities.log("Hello world") # => * | Hello world
```

### Changelog
- First commit and publish, available methods log, query_to_dict, random_sort